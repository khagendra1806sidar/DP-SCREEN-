package com.dilesh.dpscreen

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity

/**
 * Safe starter UI for a permission-based screen-sharing app.
 *
 * This starter intentionally does not capture or transmit a screen yet.
 * The system MediaProjection consent dialog is the required first step.
 */
class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                status.text = "Permission granted for this session. Streaming is not configured yet."
                Toast.makeText(this, "Screen-sharing permission granted", Toast.LENGTH_SHORT).show()
                // Next implementation step: start a foreground service and create a WebRTC video track.
                // Do not persist result.data or attempt to restart capture without fresh user consent.
            } else {
                status.text = "Screen sharing not started. Permission was denied or cancelled."
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xFFF7F9FC.toInt())
        }

        val logo = ImageView(this).apply {
            setImageResource(R.drawable.dp_screen_logo)
            contentDescription = "DP Screen logo"
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(0, 0, 0, 18)
        }
        val title = TextView(this).apply {
            text = "DP Screen"
            textSize = 26f
            setTextColor(0xFF101828.toInt())
            gravity = Gravity.CENTER
        }
        val description = TextView(this).apply {
            text = "Permission-based screen sharing between your own devices."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 18)
        }
        status = TextView(this).apply {
            text = "Status: Not connected"
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 22)
        }
        val startButton = Button(this).apply {
            text = "Allow screen sharing"
            setOnClickListener { requestScreenCaptureConsent() }
        }
        val stopButton = Button(this).apply {
            text = "Disconnect / stop"
            setOnClickListener {
                status.text = "Stopped. No screen is being shared by this starter."
                Toast.makeText(this@MainActivity, "Sharing stopped", Toast.LENGTH_SHORT).show()
            }
        }
        val note = TextView(this).apply {
            text = "This starter requests Android's visible screen-capture consent. Remote live video and secure pairing still need to be configured."
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 0)
        }

        root.addView(logo, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 150
        ))
        root.addView(title, match())
        root.addView(description, match())
        root.addView(status, match())
        root.addView(startButton, match())
        root.addView(stopButton, match())
        root.addView(note, match())
        setContentView(root)
    }

    private fun requestScreenCaptureConsent() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(manager.createScreenCaptureIntent())
    }

    private fun match() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
