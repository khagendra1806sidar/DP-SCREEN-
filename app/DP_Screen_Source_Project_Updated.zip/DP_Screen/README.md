# DP Screen — Android Studio source project

A privacy-first starter project for screen sharing between devices you own. It is deliberately permission-based and does **not** contain stealth capture, hidden monitoring, or bypasses for Android consent.

## Current state

This is a **starter UI**, not a finished remote-viewing app. The DP Screen logo is included and shown in the app. It opens Android's system screen-capture consent dialog and reflects the result. It does not yet capture, encode, or send video to another device. A secure live-viewing implementation needs a WebRTC media pipeline, a foreground service, authenticated signaling, and a TURN server for many mobile-network combinations.

## Current limitation

This ZIP is source code, not an installable APK. It has not been compiled or device-tested in this environment. Do not install it directly; open it in Android Studio to build it. Live remote viewing is not functional yet.

## Requirements

- Android Studio with Android SDK 35 installed
- JDK 17
- Android 8.0+ device (API 26+); newer Android versions may require additional foreground-service declarations and behavior updates
- Internet connection for Gradle dependencies

## Open and run

1. Extract the ZIP.
2. In Android Studio, choose **Open** and select this folder.
3. Let Gradle sync.
4. Run the `app` configuration on an Android device.
5. Tap **Allow screen sharing** and review the Android system prompt.

The app currently demonstrates the consent flow only. It does not stream anything remotely.

## Recommended next implementation phases

1. **Sender foreground service:** implement `MediaProjection` capture in a foreground service, with a persistent notification and an obvious Stop action. Re-request consent for each new capture session as required by the Android version.
2. **WebRTC media:** add a maintained Android WebRTC SDK, create a screen video source/track from the projection frames, and negotiate a peer connection.
3. **Signaling:** use a `wss://` WebSocket endpoint to exchange SDP offers/answers and ICE candidates. Do not expose a signaling server directly without authentication and rate limiting.
4. **Pairing and access:** pair devices using a short-lived one-time code or QR code; bind sessions to an authenticated account/device key. Never rely on a hard-coded PIN.
5. **Connectivity:** configure STUN and an authenticated TURN service. TURN credentials should be short-lived; do not commit server secrets.
6. **Viewer UI:** render the remote WebRTC video track and provide a clear disconnect control.
7. **Security review:** use TLS, rotate tokens, expire sessions, avoid recording by default, and test on each Android version.

## Security and privacy

- Only share a device after its owner approves Android's system prompt.
- Keep a visible foreground-service notification while capture is active.
- Stop capture immediately when the user taps Stop or disconnects.
- Do not hide the app, notification, or capture indicator.
- Do not store screen recordings unless the user explicitly enables that feature.
- Do not ship private server keys or TURN secrets inside the APK.

## Important

A working remote screen-viewing app cannot be completed by adding only a screen-capture permission. WebRTC and a deployed signaling/TURN service are required. This source project is a safe starting point, not a compiled or tested APK.
