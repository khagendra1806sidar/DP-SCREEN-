# Signaling server placeholder

The Android starter does not yet connect to this folder. For a production WebRTC implementation, deploy a WebSocket signaling service over TLS (`wss://`) that:

- authenticates each device;
- allows only explicitly paired devices into a room;
- validates message size and message type;
- expires room codes quickly and prevents reuse;
- rate-limits connection attempts;
- forwards only SDP offers/answers and ICE candidates to the paired peer;
- never stores video frames.

Use a maintained WebSocket library and a production TLS reverse proxy. Do not deploy an unauthenticated public signaling relay.
